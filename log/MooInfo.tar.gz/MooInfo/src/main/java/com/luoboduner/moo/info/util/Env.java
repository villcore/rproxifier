package com.luoboduner.moo.info.util;

public class Env {

    public static String getRproxiferServerAddr() {
        return "http://localhost:8000";
    }
}
